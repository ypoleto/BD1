CREATE TABLE tipoConvenio (
  id INT NOT NULL,
  nome VARCHAR(45) NOT NULL,
  descricao VARCHAR(100),
  PRIMARY KEY (id));

CREATE TABLE Convenio (
  idConvenio INT NOT NULL,
  nomeConvenio VARCHAR(45) NOT NULL,
  cidade VARCHAR(45) NOT NULL,
  tipoConvenio_id INT NOT NULL,
  PRIMARY KEY (idConvenio),
    FOREIGN KEY (tipoConvenio_id) REFERENCES tipoConvenio (id));

CREATE TABLE  Paciente (
  cpf INT NOT NULL,
  nomePaciente VARCHAR(100) NOT NULL,
  dataNasc VARCHAR(45) NOT NULL,
  Convenio_idConvenio INT NOT NULL,
  PRIMARY KEY (cpf),
    FOREIGN KEY (Convenio_idConvenio) REFERENCES Convenio (idConvenio));

CREATE TABLE telefones (
    nome CHAR(20) NOT NULL,
    ddd INT NOT NULL,
    telefone INT NOT NULL,
    cpf INT NOT NULL,
    PRIMARY KEY (nome),
    FOREIGN KEY (cpf)
        REFERENCES Paciente (cpf)
        ON DELETE CASCADE
);

CREATE TABLE enderecos( nome CHAR(20) NOT NULL,
			logradouro VARCHAR(100) NOT NULL,
			numero INT NOT NULL,
			bairro VARCHAR (20) NOT NULL,
            cpf INT NOT NULL, 
	     PRIMARY KEY(nome),
	     FOREIGN KEY(cpf) REFERENCES Paciente(cpf)ON DELETE
	     CASCADE);

CREATE TABLE Medico (
  CRM INT NOT NULL,
  nome VARCHAR(100) NOT NULL,
  especialidade VARCHAR(45) NOT NULL,
  endereco VARCHAR(45) NOT NULL,
  telefone VARCHAR(45) NOT NULL,
  dataNasc DATE NOT NULL,
  entradaPlantao TIME NOT NULL,
  saidaPlantao TIME NOT NULL,
  PRIMARY KEY (CRM));

CREATE TABLE Enfermeira (
    CIP INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    endereco VARCHAR(45) NOT NULL,
    telefone VARCHAR(45) NOT NULL,
    dataNasc DATE NOT NULL,
    entradaPlantao TIME NOT NULL,
    saidaPlantao TIME NOT NULL,
    PRIMARY KEY (CIP)
);

CREATE TABLE tipoEquipamento (
  id INT NOT NULL,
  nome VARCHAR(45) NOT NULL,
  quantidadeEstoque INT NOT NULL,
  PRIMARY KEY (id));

CREATE TABLE Equipamento (
  idEquipamento INT NOT NULL,
  descricao VARCHAR(100) NOT NULL,
  tipo_equipamento_id INT NOT NULL,
  PRIMARY KEY (idEquipamento),
    FOREIGN KEY (tipo_equipamento_id) REFERENCES tipoEquipamento (id));


CREATE TABLE utiliza (
  quantidadeUtilizada INT NOT NULL,
  dataUtilizacao DATE NOT NULL,
  Equipamento_idEquipamento INT NOT NULL,
  Enfermeira_CIP INT NOT NULL,
  PRIMARY KEY (quantidadeUtilizada, dataUtilizacao),
    FOREIGN KEY (Equipamento_idEquipamento) REFERENCES Equipamento (idEquipamento),
    FOREIGN KEY (Enfermeira_CIP) REFERENCES Enfermeira (CIP));

CREATE TABLE Consulta (
  idConsulta INT NOT NULL,
  data DATE NOT NULL,
  hora TIME NOT NULL,
  descricao VARCHAR(100) NOT NULL,
  salaConsulta VARCHAR(45) NOT NULL,
  Medico_CRM INT NOT NULL,
  Paciente_cpf INT NOT NULL,
  PRIMARY KEY (idConsulta),
    FOREIGN KEY (Medico_CRM) REFERENCES Medico (CRM),
    FOREIGN KEY (Paciente_cpf) REFERENCES Paciente (cpf));

CREATE TABLE Internacao (
    numero INT NOT NULL,
    dataEntrada DATE NOT NULL,
    dataSaida DATE NOT NULL,
    horaEntrada TIME NOT NULL,
    horaSaida TIME NOT NULL,
    Medico_CRM INT NOT NULL,
    Enfermeira_CIP INT NOT NULL,
    Paciente_cpf INT NOT NULL,
    quantidadeEquipamentos INT NOT NULL,
    dataUtilizacaoEquipamentos DATE NOT NULL,
    PRIMARY KEY (numero),
    FOREIGN KEY (Medico_CRM)
        REFERENCES Medico (CRM),
    FOREIGN KEY (Enfermeira_CIP)
        REFERENCES Enfermeira (CIP),
    FOREIGN KEY (Paciente_cpf)
        REFERENCES Paciente (cpf),
    FOREIGN KEY (quantidadeEquipamentos , dataUtilizacaoEquipamentos)
        REFERENCES utiliza (quantidadeUtilizada , dataUtilizacao)
);